#include "ALU.hpp"

ALU &ALU::getInstance()
{
	static ALU alu;
	return alu;
}

int ALU::add(int *rs, int *rt)
{

	return *rs + *rt;
}

int ALU::sub(int *rs, int *rt)
{
	return *rs - *rt;
}

int ALU::mul(int *rs, int *rt)
{
	return *rs * *rt;
}

int ALU::div(int *rs, int *rt)
{
	return *rs / *rt;
}

int ALU::mod(int *rs, int *rt)
{
	return *rs % *rt;
}

int ALU::sll(int *rt, int shamt)
{
	return *rt >> shamt;
}

int ALU::srl(int *rt, int shamt)
{
	return *rt << shamt;
}

int ALU::and_op(int *rs, int *rt)
{
	return *rs & *rt;
}

int ALU::orr(int *rs, int *rt)
{
	return *rs | *rt;
}

int ALU::nor(int *rs, int *rt)
{
	return !(*rs | *rt);
}

int ALU::slt(int *rs, int *rt)
{
	return (*rs < *rt ? 1 : 0);
}

int ALU::addi(int *rs, int immediate)
{
	return *rs + immediate;
}

int ALU::subi(int *rs, int immediate)
{
	return *rs - immediate;
}

int ALU::muli(int *rs, int immediate)
{
	return *rs * immediate;
}

int ALU::andi(int *rs, int immediate)
{
	return *rs & immediate;
}

int ALU::ori(int *rs, int immediate)
{
	return *rs | immediate;
}

int ALU::divi(int *rs, int immediate)
{
	return *rs / immediate;
}

int ALU::modi(int *rs, int immediate)
{
	return *rs % immediate;
}

int ALU::slti(int *rs, int immediate)
{
	return (*rs < immediate ? 1 : 0);
}

int ALU::seq(int *rs, int immediate)
{
	return (*rs == immediate ? 1 : 0);
}

int ALU::beq(int *rs, int *rt, int address)
{
	BEQ beq(rs, rt, address);
	return beq.run();
}
int ALU::bne(int *rs, int *rt, int address)
{
	BNE bne(rs, rt, address);
	return bne.run();
}
