#include "execute.hpp"
#include <iostream>
extern int executed_instructions;
extern int g_clock;
extern bool branch_taken;

int nop_count = 0;
int missed_branch = 0;

int execute(ALU &alu, ISA instructions, int registers[64], vector<int> register_file, int immediate)
{
	int result;
	switch (instructions)
	{
	case ADD:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.add(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ ADD ] " << alu.add(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}

		break;
	case SUB:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.sub(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ SUB ] " << alu.sub(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}

		break;
	case MUL:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 2;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.mul(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ MUL ] " << alu.mul(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}
		break;
	case DIV:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 5;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.div(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ DIV ] " << alu.div(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}
		break;
	case MOD:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 5;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.mod(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ MOD ] " << alu.mod(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}
		break;
	case SLL:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.sll(&registers[register_file[1]], immediate);
			cout << " [ SLL ] " << alu.sll(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case SRL:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.srl(&registers[register_file[1]], immediate);
			cout << " [ SRL ] " << alu.srl(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case AND:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.and_op(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ AND ] " << alu.and_op(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}
		break;
	case ORR:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.orr(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ ORR ] " << alu.orr(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}
		break;
	case NOR:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.nor(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ NOR ] " << alu.nor(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}
		break;
	case SLT:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.slt(&registers[register_file[1]], &registers[register_file[2]]);
			cout << " [ SLT ] " << alu.slt(&registers[register_file[1]], &registers[register_file[2]]) << endl;
		}
		break;
	case ADDI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.addi(&registers[register_file[1]], immediate);
			cout << " [ ADDI ] " << alu.addi(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case SUBI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.subi(&registers[register_file[1]], immediate);
			cout << " [ SUBI ] " << alu.subi(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case MULI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.muli(&registers[register_file[1]], immediate);
			cout << " [ MULI ] " << alu.muli(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case DIVI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 5;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.divi(&registers[register_file[1]], immediate);
			cout << " [ DIVI ] " << alu.divi(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case ANDI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.andi(&registers[register_file[1]], immediate);
			cout << " [ ANDI ] " << alu.andi(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case ORI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.ori(&registers[register_file[1]], immediate);
			cout << " [ ORI ] " << alu.ori(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case MODI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 5;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.modi(&registers[register_file[1]], immediate);
			cout << " [ MODI ] " << alu.modi(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case SLTI:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 1;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.slti(&registers[register_file[1]], immediate);
			cout << " [ SLTI ] " << alu.slti(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case BEQ:
		result = alu.beq(&registers[register_file[0]], &registers[register_file[1]], immediate);
		cout << " [ BEQ ] ";
		if (branch_taken)
		{
			missed_branch++;
			cout << "Taken: ";
		}
		else
		{
			cout << "Not Taken ";
		}
		cout << result << endl;
		break;
	case BNE:
		result = alu.bne(&registers[register_file[0]], &registers[register_file[1]], immediate);
		cout << " [ BNE ] ";
		if (branch_taken)
		{
			missed_branch++;
			cout << "Taken: ";
		}
		else
		{
			cout << "Not Taken ";
		}
		cout << result << endl;
		break;
	case SEQ:
		if (alu.m_lock == false)
		{
			alu.m_lock = true;
			alu.m_delay = 3;
		}
		alu.m_delay--;
		if (alu.m_delay == 0)
		{
			alu.m_lock = false;
			result = alu.seq(&registers[register_file[1]], immediate);
			cout << " [ SEQ ] " << alu.seq(&registers[register_file[1]], immediate) << endl;
		}
		break;
	case EOP:
		cout << " [ EOP ] Program terminated successfully " << endl;
		cout << " { " << (executed_instructions + nop_count) << " } Instructions Executed " << endl;
		cout << " { " << (executed_instructions) << " } Useful Instructions Executed " << endl;
		cout << " { " << ceil(g_clock) << " } Clock Cycles Taken " << endl;
		cout << " { " << (executed_instructions + nop_count) / (ceil(g_clock)) << " } Instructions per Cycle" << endl;
		cout << " { " << nop_count << " } NOP Instructions" << endl;
		cout << " { " << missed_branch << " } Miss-Predicted Branches" << endl;
		exit(EXIT_SUCCESS);

	case NOP:
		cout << " [ NOP ]\n";
		nop_count++;
		g_clock++;
		break;
	}
	if (!alu.m_lock)
	{
		executed_instructions++;
	}
	return result;
}

void end()
{
	cout << " [ EOP ] Program terminated successfully " << endl;
	cout << " { " << (executed_instructions + nop_count) << " } Instructions Executed " << endl;
	cout << " { " << (executed_instructions) << " } Useful Instructions Executed " << endl;
	cout << " { " << ceil(g_clock) << " } Clock Cycles Taken " << endl;
	cout << " { " << setprecision(3) << (executed_instructions + nop_count) / (ceil(g_clock))
	     << " } Instructions per Cycle" << endl;
	cout << " { " << nop_count << " } NOP Instructions" << endl;
	cout << " { " << missed_branch << " } Miss-Predicted Branches" << endl;
	exit(EXIT_SUCCESS);
}
